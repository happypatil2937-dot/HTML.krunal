MTF-X Trading Analyzer — Prototype

FILES
- index.html: complete single-file responsive website prototype.

HOW TO RUN
1. Download index.html to your Android phone or computer.
2. Open it in Chrome, Edge, Firefox, or another modern browser.
3. Internet access is needed for live public Binance spot/futures market data.
4. Choose a coin and timeframe. The page refreshes data automatically about every 20 seconds.
5. Upload a chart screenshot to preview it, then press Analyze setup for a transparent rule-based signal preview.
6. Add price alerts; alerts are checked only while the page remains open. Browser notifications are optional.
7. Use the risk calculator and journal; their data is stored locally in the same browser.

IMPORTANT LIMITATIONS
- This is a working front-end prototype, not a deployed cloud service.
- Screenshot upload is preview-only. True AI image interpretation needs a secure backend and AI API integration.
- Live OI/funding may fail for unsupported symbols or if Binance APIs are blocked by your network. The prototype displays N/A when unavailable.
- No exchange order placement, account connection, server-side push alerts, or guaranteed signals.
- Market data is informational only. Verify levels and risk before trading.
